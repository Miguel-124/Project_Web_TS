<!-- view/TaskListView.vue -->
<template>
  <div class="container">
    <h1>Zadania historyjki</h1>

    <!-- Formularz dodawania zadania -->
    <form @submit.prevent="addTask" class="form-wrapper">
      <div class="form-fields">
        <input v-model="newTask.name" placeholder="Nazwa zadania" required />
        <textarea
          v-model="newTask.description"
          placeholder="Opis zadania"
          ref="textareaRef"
          @input="autoResize"
          rows="2"
        />
        <select v-model="newTask.priority">
          <option value="low">Niski</option>
          <option value="medium">Średni</option>
          <option value="high">Wysoki</option>
        </select>
        <input
          type="number"
          v-model.number="newTask.estimatedTime"
          placeholder="Szacowany czas (h)"
          min="1"
        />
      </div>
      <button type="submit" class="btn btn-add">Dodaj zadanie</button>
    </form>

    <!-- Widok Kanban -->
    <div class="kanban-board">
      <div v-for="status in statuses" :key="status" class="kanban-column">
        <h2 class="kanban-title">{{ statusMap[status] }}</h2>
        <div class="kanban-cards">
          <div v-for="task in filteredTasks(status)" :key="task.id" class="kanban-card">
            <strong>{{ task.name }}</strong>
            <p>{{ task.description }}</p>
            <small> Priorytet: {{ task.priority }} | Czas: {{ task.estimatedTime }}h </small>
            <div class="kanban-actions">
              <router-link :to="`/tasks/${task.id}`" class="btn btn-edit"> Szczegóły </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { TaskService } from '@/services/TaskService'
import type { Task, TaskStatus, TaskPriority, NewTask } from '@/models/Task'
import { useAutoResizeTextarea } from '@/composables/useAutoResizeTextarea'

const { textareaRef, autoResize } = useAutoResizeTextarea()
const taskService = new TaskService()
const route = useRoute()

const storyId = route.params.storyId as string
const tasks = ref<Task[]>([])

// 🔸 Typ lokalny – tylko dane z formularza
const newTask = ref<{
  name: string
  description: string
  priority: TaskPriority
  estimatedTime: number
}>({
  name: '',
  description: '',
  priority: 'medium',
  estimatedTime: 1,
})

const statuses: TaskStatus[] = ['todo', 'in progress', 'done']
const statusMap: Record<TaskStatus, string> = {
  todo: 'Do zrobienia',
  'in progress': 'W trakcie',
  done: 'Zrobione',
}

onMounted(() => {
  tasks.value = taskService.getByStory(storyId)
})

// ✅ Budowanie pełnego obiektu NewTask przy tworzeniu
function addTask() {
  const taskToCreate: NewTask = {
    ...newTask.value,
    storyId,
    status: 'todo',
    createdAt: new Date().toISOString(),
  }

  taskService.create(taskToCreate)
  tasks.value = taskService.getByStory(storyId)

  newTask.value = {
    name: '',
    description: '',
    priority: 'medium',
    estimatedTime: 1,
  }

  autoResize()
}

function filteredTasks(status: TaskStatus): Task[] {
  return tasks.value.filter((t) => t.status === status)
}
</script>

<style scoped>
.kanban-board {
  display: flex;
  gap: 1rem;
  justify-content: space-between;
  margin-top: 2rem;
}

.kanban-column {
  flex: 1;
  background-color: #1e1e1e;
  border-radius: 1rem;
  padding: 1rem;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
}

.kanban-title {
  text-align: center;
  margin-bottom: 1rem;
  color: #60a5fa;
}

.kanban-cards {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.kanban-card {
  background-color: #2a2a2a;
  padding: 1rem;
  border-radius: 0.75rem;
  border: 1px solid #444;
}

.kanban-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 0.5rem;
}
</style>
