<template>
  <div class="p-6 max-w-3xl mx-auto">
    <router-view />
  </div>
</template>

<script setup lang="ts"></script>
