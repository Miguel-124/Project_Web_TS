import { ref, watch } from 'vue'

const STORAGE_KEY = 'activeProjectId'
const activeProjectId = ref<string | null>(localStorage.getItem(STORAGE_KEY))

watch(activeProjectId, (newId) => {
  if (newId) {
    localStorage.setItem(STORAGE_KEY, newId)
  } else {
    localStorage.removeItem(STORAGE_KEY)
  }
})

function setActive(id: string | null) {
  activeProjectId.value = activeProjectId.value === id ? null : id
}

export function useActiveProject() {
  return {
    activeProjectId,
    setActive,
  }
}
